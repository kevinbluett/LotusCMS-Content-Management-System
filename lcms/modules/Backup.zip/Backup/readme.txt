This module uses the pclzip library, 

from
http://www.phpconcept.net

under the gnu-lgp license.