<?php

class MenuModule extends Module{

	

}

?>