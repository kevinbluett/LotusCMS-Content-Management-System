<?php

include("core/view/view.php");
include("core/lib/table.php");

class ModuleLoaderView extends View{
	
	
	/**
	 * Starts the controller of the classes system
	 */
	public function ModuleLoaderView(){
			
	}	
}

?>